#include<iostream>
using namespace std;
int main()
{
	int sum=0, count=0, num=0;
	for(;;)
	{
		cout<<"Enter ann Integer(enter 9999 to stop): "<<endl;
		cin>>num;
		if(num==9999)
		{
			break;
		}
		sum=sum+num;
		count++;
	}
	double avg=sum/double(count);
	cout<<"Average: "<<avg;
	return 0;
}

