#include<iostream>
using namespace std;
int main()
{
	int a=1, b=5, i=1;
	while(i<=5)
	{
		cout<<"a\tb" <<endl;
		cout<<a<<"\t"<<b<<endl;
		a++;
		b++;
		i++;
	}

	return 0;
}
