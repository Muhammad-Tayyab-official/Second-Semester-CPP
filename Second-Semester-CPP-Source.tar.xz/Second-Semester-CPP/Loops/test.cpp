#include<iostream>
#include<cmath>
using namespace std;
int main()
{        // simple Output of array
            // int marks[5]= {10,20,30,40,50};
            // // cout<<marks[0]<<endl;
            // // cout<<marks[1]<<endl;
            // // cout<<marks[2]<<endl;
            // // cout<<marks[3]<<endl;
            // // cout<<marks[4]<<endl;
        //Output Via Loop
            // int marks1[5]={ 10,20,30,40,50};
            // for(int i=0; i<=4; i++)
            // {
            //     cout<<marks1[i]<<endl;
            // }
        //Input of Array Via Loop
            // int marks2[5];
            // for(int i=0; i<5; i++)
            // {
            //     cout<<"Enter MArks of "<<i+1<<"th student: ";
            //     cin>>marks2[i];
            // }
        //Output Loop:
            // for(int i=0; i<5; i++)
            // {
            //     cout<<"Marks of "<<i+1<<"th student is: "<<marks2[i]<<endl;
            // }
        //Finding Smallest Number:
            // int nums[5]={10,30,5,50,23};
            // int  smallest= INT_MAX ;
            // int index=0;
            // for(int i=0; i<5; i++)
            // {
            //     if(nums[i]<smallest)
            //     {
            //         smallest=nums[i];
            //         index=i;
            //     }
            // }
            // cout<<"Smallest Number is: "<<smallest<<endl;
            // cout<<"Index of Smallest Number is: "<<index<<endl;
          

        //Finding Largest Via Input from user:
            // int nums1[5];
            // int index1=0;
            // for(int i=0; i<5; i++)
            // {
            //     cout<<"Enter Number "<<i+1<<" :";
            //     cin>>nums1[i];
            // }
            // for(int i=0; i<5; i++)
            // {
            //     cout<<"Number "<<i+1<<" is: "<<nums1[i]<<endl;
            // }
            // int largest=INT_MIN;
            // for(int i=0; i<5; i++)
            // {
            //     if(nums1[i]>largest)
            //     {
            //         largest=nums1[i];
            //         index1=i;
            //     }
            // }
            // cout<<"Largest Number is: "<<largest<<endl;
            // cout<<"Index of Largest Number is: "<<index1<<endl;
        //Linear Search:
            // int nums2[5]={10,20,30,40,50};
            // int target;
            // cout<<"Enter Target Number: ";
            // cin>>target;
            // for(int i=0; i<5; i++)
            // {
            //     if(nums2[i]==target)
            //     {
            //         cout<<
            //     }
            // }

// int row, col, input;
// long units[row][col], t[row];
// cout<<"Enter Total Number of Houses: ";
// cin>>row;
// cout<<"Enter Total Days: ";
// int lim=200;
// for(int r=0; r<row; r++)
// {
//     for(int c=0; c<col; c++)
//     {
//         cout<<"Enter Units Consumed: ";
//         cin>>input;
//         if(input>0)
//         {
//             if(input>200)
//             {
//                 cout<<"Critical Limit Incresead";
//                 break;
//             }
//             else
//             {
//                 units[r][c]=input;
//                 t[r]+=input;
//             }
//         }
//         else
//         {
//             cout<<"Invalid Value!!!";
//             continue;
//         }
//         if(input<200)
//         {
//             cout<<"High Energy Consumption by House "<<r+1<<endl;
//         }
//         else if(input>150 && input<=200)
//         {
//             cout<<"Moderate Consumtion by House "<<r+1<<endl;
//         }
//         else 
//         {
//             cout<<"Low Consumption by House "<<r+1<<endl;
//         }
//     }
// }
// for(int r=0; r<row; r++)
// {
//     cout<<"Total Units Consumed for House:  "<<r+1<<" are "<<t[r];
//     cout<<"Average Units Consumed by House: "<<r+1<<" are "<<t[r]/float(col); 
// }
          
// int digit, num;
// cout<<"Enter a Number: ";
// cin>>num;

// while(num !=0)
// 	{
// 		digit=num%10;
// 		cout<<digit<<" ";
// 		num=num/10;
// 	}



// int num;
// cout<<"Enter a Number: ";
// cin>>num;
// int temp, org;
// temp=org=num;
// int sum=0, dig=0;
// while (temp!=0)
// {
//     temp=temp/10;
//     dig++;
// }
// while(org!=0)
// {
//     int reminder=org%10;
//     sum=sum+pow(reminder,dig);
//     org=org/10;
// }
// if(sum==num)
// {
//     cout<<num <<" is Armstrong."<<endl;
// }
// else
// {
//     cout<<" Not Armsrong."<<endl;
// }

    return 0;
}
