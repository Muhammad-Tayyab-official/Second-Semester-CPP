#include <iostream>
using namespace std;
int main()
{
	int drone = 2;
	int trip = 2;
	int max_lim = 100;
	int time_taken;
	double avg;
	long time[drone][trip];
	for (int r = 0; r < drone; r++)
	{
		for (int c = 0; c < trip; c++)
		{
			cout << "Enter Time Taken by Drone " << r + 1 << " in trip No. " << c + 1 << " in Hours: ";
			cin >> time[r][c];
		}
	}
	for (int r = 0; r < drone; r++)
	{
		int total = 0, num = 0;

		for (int c = 0; c < trip; c++)
		{
			time_taken = time[r][c];
			if (time_taken < 0)
			{
				continue;
			}

			if (total + time_taken < max_lim)
			{
				cout << "The Drone " << r + 1 << " is exceeding Maximum limit." << endl;
				total = total + time_taken;
				num++;
				break;
			}
			else
			{
				total = total + time_taken;
				num++;
			}
		}
		
		if (num > 0)
		{

			avg = double(total) / double(num);
		}
		else
		{
			avg = 0;
		}
		cout << "Total time Consumed by Drone " << r + 1 << "is : " << total << endl;
		cout << "Average time Consumed by Drone " << r + 1 << "is : " << avg << endl;
		if (avg > 50)
		{
			cout << r + 1 << " is Delayed!!" << endl;
		}
		else if (avg > 20 && avg < 50)
		{
			cout << r + 1 << " is Moderate." << endl;
		}
		else
		{
			cout << r + 1 << " is Efficient." << endl;
		}
	}
	return 0;
}
