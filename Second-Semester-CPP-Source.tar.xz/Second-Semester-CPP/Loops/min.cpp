#include<iostream>
using namespace std;
int main()
{
	int n, min;
	cout<<"Enter Number 1: "<<endl;
	cin>>n;
	min=n;
	for(int i=2; i<=5; i++)
	{
		cout<<"Enter Number "<<i<<": "<<endl;
		cin>>n;
		if(n<min)
		{
			min=n;
		}
	}
cout<<"Minimum Value is "<<min<<endl;
	return 0;
}

