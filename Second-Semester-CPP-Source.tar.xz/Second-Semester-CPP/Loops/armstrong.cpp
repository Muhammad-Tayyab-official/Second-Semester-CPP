#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int j;
	cout<<"Enter Any  Number: ";
	cin>>j;
	for(int i=1; i<=j; i++)
	{
		int org=i;
		int temp=i;
		int dig=0;
		int sum=0;
	while(temp!=0)
	{
		temp=temp/10;
		dig++;
	}
	temp=i;
	while(temp!=0)
	{
		int digit= temp%10;
		sum=sum+ pow(digit,dig);
		temp=temp/10;
	}
	
	 if(sum==org)
	 {
	 	cout<<org<< " ";
	 }
	}
	return 0;
}


