#include <iostream>
using namespace std;

int main()
{
    int locations;
    int days;
    int hazardousLevel = 300;

    cout << "Enter number of locations: ";
    cin >> locations;
    cout << "Enter number of days: ";
    cin >> days;

    int aqi[locations][days];

    for (int r = 0; r < locations; r++)
    {
        cout << "Location " << r + 1 << ":\n";
        for (int c = 0; c < days; c++)
        {
            cout << "  AQI on day " << c + 1 << ": ";
            cin >> aqi[r][c];
        }
    }

    bool hazardousFound = false;

    for (int r = 0; r < locations; r++)
    {
        int total = 0;
        int validDays = 0;

        for (int c = 0; c < days; c++)
        {
            int value = aqi[r][c];

            if (value < 0)
            {
                cout << "  (Skipped invalid negative AQI at Location " << r + 1 << ", Day " << c + 1 << ")\n";
                continue;
            }

            if (value > hazardousLevel)
            {
                cout << "\n HAZARDOUS AQI detected at Location " << r + 1
                     << " on Day " << c + 1 << "! (AQI = " << value << ") \n";
                hazardousFound = true;
            }

            total += value;
            validDays++;
        }

        if (hazardousFound)
        {
            cout << "Monitoring stopped due to hazardous condition.\n";
            break;
        }

        double avg = (validDays > 0) ? (double)total / validDays : 0;

        cout << "\nLocation " << r + 1 << ":\n";
        cout << "  Average AQI: " << avg << endl;

        if (avg > hazardousLevel)
            cout << "  Category: HAZARDOUS\n";
        else if (avg > 100 && avg <= hazardousLevel)
            cout << "  Category: MODERATE\n";
        else
            cout << "  Category: GOOD\n";
    }

    if (!hazardousFound)
        cout << "\nNo hazardous level detected. Air quality is acceptable.\n";

    return 0;
}
