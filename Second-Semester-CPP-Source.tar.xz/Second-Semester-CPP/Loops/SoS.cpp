#include <iostream>
#include <iomanip> // For output precision

using namespace std;

int main() {
    double sum = 1.0; // Start with the first term (1)
    int n = 4;        // Start denominators at 4

    cout << "1";

    while (n <= 100) {
        sum += 1.0 / n;       // Accumulate the sum
        cout << " + 1/" << n; // Print the term
        n += 4;               // Increment denominator by 4
    }

    cout << endl;
    // Using fixed and setprecision(4) to show the result clearly
    cout << "Sum of Series: " << sum << endl;

    return 0;
}