#include<iostream>
using namespace std;
int main()
{
	int i=1, num=1, sum=0;
	cout<<"num\tsum"<<endl;
	while(i<=5)
	{
		sum+=num;
		cout<<num<<"\t"<<sum<<endl;
		i++;
		num++;
	}
	return 0;
}
