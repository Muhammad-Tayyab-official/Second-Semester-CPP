#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of values: ";
    cin >> n;

    if (n <= 0) {
        cout << "Invalid input! n must be greater than 0." << endl;
        return 1;
    }

    int num;
    int largest, smallest;
    int sum = 0;

    cout << "Enter " << n << " whole numbers: " << endl;

    // Input first number to initialize largest and smallest
    cin >> num;
    largest = smallest = num;
    sum = num;

    // Loop for remaining n-1 numbers
    for (int i = 1; i < n; i++) {
        cin >> num;

        // Update sum
        sum += num;

        // Check for largest
        if (num > largest) {
            largest = num;
        }

        // Check for smallest
        if (num < smallest) {
            smallest = num;
        }
    }

    // Calculate average
    double average=double(sum) / double(n);

    // Display results
    cout << "\nResults:" << endl;
    cout << "Largest number: " << largest << endl;
    cout << "Smallest number: " << smallest << endl;
    cout << "Average: " << average << endl;

    return 0;
}
