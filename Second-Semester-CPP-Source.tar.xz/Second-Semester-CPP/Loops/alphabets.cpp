#include<iostream>
using namespace std;
int main()
{
	for(char ch='A';ch<='Z';ch++)
	{
		cout<<ch<<"\t";
	}
	return 0;
}

