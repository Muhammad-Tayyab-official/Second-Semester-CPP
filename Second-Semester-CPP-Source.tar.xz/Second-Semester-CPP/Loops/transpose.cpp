#include<iostream>
using namespace std;
int main()
{
	int marks[3][3], trans[3][3];
	
	for(int r=0; r<3; r++)
	{	for(int c=0; c<3; c++)
	{
	cout<<"Enter any Number : ";
		cin>>marks[r][c];			
	}	
	}
	
	for(int r=0; r<3; r++)
	{	for(int c=0; c<3; c++)
		{
		trans[c][r]=marks[r][c];	
		}	
	}
	
	for(int r=0; r<3; r++)
	{	for(int c=0; c<3; c++)
		{
			
		cout<<marks[r][c]<<" ";		
		}
	cout<<endl;	
	}
	
	cout<<"\nTranspose :"<<endl;
	
	for(int r=0; r<3; r++)
	{	for(int c=0; c<3; c++)
		{
			
		cout<<trans[r][c]<<" ";		
		}
	cout<<endl;	
	}	
}
