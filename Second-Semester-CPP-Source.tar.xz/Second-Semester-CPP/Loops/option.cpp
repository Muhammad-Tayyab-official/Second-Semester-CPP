#include<iostream>
using namespace std;
int main()
{
	int a=0,b=0,c=0,d=0;
	for (int i=1; i<=20; i++)
	{
		char ch;
		cout<<"Choose any one Option from a, b, c, d. "<< endl;
		cin>>ch;
		switch(ch)
	{
		case 'a':
			a++;
			break;
		case 'b':
			b++;
			break;
		case 'c':
			c++;
			break;
		case 'd':
			d++;
			break;
		default:
			cout<<"Invalid Option!"<<endl;
			i--;
			break;
	}
}
cout<<"You have choose 'a' "<<a<<" times."<<endl;
cout<<"You have choose 'b' "<<b<<" times."<<endl;
cout<<"You have choose 'c' "<<c<<" times."<<endl;
cout<<"You have choose 'd' "<<d<<" times."<<endl;
	return 0;
}

