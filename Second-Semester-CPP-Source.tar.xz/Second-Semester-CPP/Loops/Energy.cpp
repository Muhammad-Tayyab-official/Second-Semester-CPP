#include <iostream>
using namespace std;
int main()
{
	int hours = 2;
	int app = 2;
	int safe_lim = 100;
	long energy[app][hours];

	for (int r = 0; r < app; r++)
	{
		for (int c = 0; c < hours; c++)
		{
			cout << "Enter Energy Consumption Units for Appliance " << r + 1 << " in Hour " << c + 1 << ": ";
			cin >> energy[r][c];
		}
	}

	for (int r = 0; r < app; r++)
	{
		int total = 0;
		int vHour = 0;
		for (int c = 0; c < hours; c++)
		{
			int units = energy[r][c];
			if (units < 0)
			{
				continue;
			}

			total += units;
			vHour++;

			if (total > safe_lim)
			{
				cout << "Appliance " << r + 1 << " has exceeded the safe limit at Hour " << c + 1 << endl;
				break;
			}
		}

		double avg;
		if (vHour > 0)
			avg = double(total) / vHour;
		else
			avg = 0;

		cout << "Average Energy Consumption for Appliance " << r + 1 << " is: " << avg << endl;
		cout << "Total Energy Consumption for Appliance " << r + 1 << " is: " << total << endl;

		if (avg > 40)
			cout << "High Energy Consumption for Appliance " << r + 1 << endl;
		else if (avg > 20 && avg <= 40)
			cout << "Moderate Energy Consumption for Appliance " << r + 1 << endl;
		else
			cout << "Low Energy Consumption for Appliance " << r + 1 << endl;
	}
	return 0;
}
