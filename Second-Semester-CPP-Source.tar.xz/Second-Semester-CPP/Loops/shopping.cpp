#include <iostream>
using namespace std;

int main()
{
    int customers;
    int items;
    cout << "Enter number of customers: ";
    cin >> customers;
    cout << "Enter number of items per customer: ";
    cin >> items;

    float price[customers][items];

    for (int r = 0; r < customers; r++)
    {
        cout << "Customer " << r + 1 << ":\n";
        for (int c = 0; c < items; c++)
        {
            cout << "  Price of item " << c + 1 << ": ";
            cin >> price[r ][c];
        }
    }

    for (int r = 0; r < customers; r++)
    {   
        float total = 0;
        int validItems = 0;

        for (int c = 0; c < items; c++)
        {
            float p = price[r][c];
            if (p < 0)
            {
                cout << "  (Skipped invalid negative price for Customer " << r + 1 << ", Item " << c + 1 << ")\n";
                continue;
            }
            total += p;
            validItems++;
        }

        float discount = 0;
        if (total > 500)
        {
            discount = total * 0.10;
            total = total - discount;
            cout << "Customer " << r + 1 << " got a 10% discount! ";
        }

        cout << "Total bill for Customer " << r + 1 << " = Rs. " << total;
        if (discount > 0)
            cout << " (after discount of Rs. " << discount << ")";
        cout << endl;
    }

    return 0;
}
