#include <iostream>
using namespace std;
int main()
{
	int reserviors;
	int days;
	int min_lim = 1000;
	cout << "Enter Reserviors : ";
	cin >> reserviors;
	cout << "Enter Days: ";
	cin >> days;
	int total, num;
	double avg;
	long water[reserviors][days];
	for (int r = 0; r < reserviors; r++)
	{
		for (int c = 0; c < days; c++)
		{
			cout << "Enter Number of Reserviors " << r + 1 << " for day " << c + 1 << " : ";
			cin >> water[r][c];
		}
	}
	for (int r = 0; r < reserviors; r++)
	{
		total = 0;
		num = 0;

		for (int c = 0; c < days; c++)
		{
			int water_level = water[r][c];
			if (water_level < 0)
			{
				continue;
			}
			if (total + water_level < min_lim)
			{
				cout << "Critical Shortage for Resorvior  " << r + 1 << endl;
				total = total + water_level;
				num++;
			}
			else
			{
				total = total + water_level;
				num++;
			}
		}
		if (num > 0)
		{
			avg = double(total) / double(num);
		}
		else
		{
			avg = 0;
		}
		cout << "Total for " << " resorvior" << r + 1 << " is : " << total << endl;
		cout << "Average for " << "resorvior" << r + 1 << " is : " << avg << endl;
		if (avg > 50)
		{
			cout << "Resorvior " << r + 1 << " Status:  Overflow!" << endl;
		}
		else if (avg > 20 && avg < 50)
		{
			cout << "Resorvior " << r + 1 << " Status: Normal." << endl;
		}
		else
		{
			cout << "Resorvior " << r + 1 << " Status: Low." << endl;
		}
	}

	return 0;
}
