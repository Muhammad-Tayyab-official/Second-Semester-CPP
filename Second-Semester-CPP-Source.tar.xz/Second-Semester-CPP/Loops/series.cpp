#include<iostream>
using namespace std;
int main()
{
	int n, max=0, min=0;
	cout<<"Enter Any Positive Number: ";
	cin>>n;
	if (n<0)
	{
		cout<<"Invalid Input!"<<endl;
		
	}
	int num=0; max, min;
	int sum=0;
	max=min=sum=num;
	for(int i=1; i<n; i++)
	{
		sum+=num;
		num++;
		if(num>max)
		{
			max=num;
		}
		if(num<=min)
		{
			min=num;
		}
	}
	double avg;
	avg= sum/double(n);
	cout<<"Max :"<<max<<endl;
	cout<<"Min: "<<min<<endl;
	cout<<"Average: "<<avg<<endl;
	return 0;
}
