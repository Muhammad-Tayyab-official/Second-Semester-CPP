#include<iostream>
using namespace std;
int main()
{
	int n;
	int marks, min, max;
	max=0;
	cout<<"Enter Number of Students in Class: ";
	cin>>n;
	cout<<"Enter the marks of students: "<<"1"<<endl;
	cin>>marks;
	min=marks;

	for(int i=2; i<=n; i++)
	{
		
		cout<<"Enter the marks of student  "<<i<<endl;
		cin>>marks;
		if(marks>max)
		{
			max=marks;
		}
		if(marks<min)
		{
			min=marks;
		}
	}
cout<<"Highest Numbers: " <<max<<endl;
cout<<"Lowest Numbers: " <<min<<endl;
return 0;
}

