#include <iostream>
using namespace std;

int main()
{
    int zones;
    int intervals;
    int maxCapacity = 50;

    cout << "Enter number of zones: ";
    cin >> zones;
    cout << "Enter number of time intervals: ";
    cin >> intervals;

    int parking[zones][intervals];
    for (int r = 0; r < zones; r++)
    {
        cout << "Zone " << r + 1 << ":\n";
        for (int c = 0; c < intervals; c++)
        {
            cout << "  Occupied slots at interval " << c + 1 << ": ";
            cin >> parking[r][c];
        }
    }

    bool capacityExceeded = false;

    for (int r = 0; r < zones; r++)
    {
        int total = 0;
        int validReadings = 0;

        for (int c = 0; c < intervals; c++)
        {
            int slots = parking[r][c];
            if (slots < 0 || slots > maxCapacity)
            {
                cout << "  (Skipped invalid sensor data at Zone " << r + 1
                     << ", Interval " << c + 1 << ")\n";
                continue;
            }

            if (slots > maxCapacity)
            {
                cout << "\n Zone " << r + 1 << " has exceeded maximum capacity ("
                     << slots << " > " << maxCapacity << ") at interval " << c + 1 << "! \n";
                capacityExceeded = true;
                break;
            }

            total += slots;
            validReadings++;
        }

        if (capacityExceeded)
        {
            cout << "Stopping further processing due to capacity violation.\n";
            break;
        }

        double avg = (validReadings > 0) ? (double)total / validReadings : 0;

        cout << "\nZone " << r + 1 << ":\n";
        cout << "  Total occupied slots (sum): " << total << endl;
        cout << "  Average occupancy: " << avg << " slots" << endl;

        if (avg >= maxCapacity * 0.8)
            cout << "  Status: FULL\n";
        else if (avg >= maxCapacity * 0.3)
            cout << "  Status: MODERATE\n";
        else
            cout << "  Status: EMPTY\n";
    }

    if (!capacityExceeded)
        cout << "\nAll zones are within safe capacity limits.\n";

    return 0;
}
