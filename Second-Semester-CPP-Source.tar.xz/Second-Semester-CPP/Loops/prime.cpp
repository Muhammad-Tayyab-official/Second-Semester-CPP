#include<iostream>
using namespace std;
int main()
{
	int n,count=0;
	cout<<"Enter A Number: ";
	cin>>n;
	for(int i=2; i<n; i++)
	{
		 count=0;
		for(int j=1; j<=i; j++)
		{
			if(i%j==0)
			{
				count++;
			}
		}
		if(count==2)
		{
			cout<<i<<" ";
		}
	}
	return 0;
}

