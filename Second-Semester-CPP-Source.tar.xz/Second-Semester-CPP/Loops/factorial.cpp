#include <iostream>
using namespace std;

int main() {
    int ch; // Declared once outside
    
    do {
        int n;
        long long fact = 1; // Use long long for larger numbers

        cout << "Enter any number for Factorial: ";
        cin >> n;

        if (n < 0) {
            cout << "Factorial is not defined for negative numbers." << endl;
        } else {
            for (int i = 1; i <= n; i++) {
                fact = fact * i;
            }
            cout << "Factorial of " << n << " is " << fact << endl;
        }

        cout << "If you want to calculate another one enter 1: " << endl;
        cout << "Press any other key to exit: ";
        cin >> ch;

    } while (ch == 1);

    return 0;
}