#include<iostream>
using namespace std;
 
struct Shipment {
    int id;
    float weight;
    float distance;
    char type;  // E = Express, N = Normal
};
 
void inputShipmentData(Shipment s[], int n) {
    for(int i=0; i<n; i++) {
        cout << "\nShipment " << i+1 << ":" << endl;
        cout << "ID: ";       cin >> s[i].id;
        cout << "Weight: ";   cin >> s[i].weight;
        cout << "Distance: "; cin >> s[i].distance;
        cout << "Type (E/N): "; cin >> s[i].type;
    }
}
 
float calculateBaseCost(float weight, float distance) {
    return (weight * 50) + (distance * 10);
}
 
float applyDeliveryTypeCharge(float cost, char type) {
    if(type == 'E' || type == 'e')
        return cost * 1.30;
    return cost;
}
 
