#include<iostream>
using namespace std;
int main()
{
	int  n;
		int marks, no;
	cout<<"Enter Number of Students: ";
	cin>> n;

	int marks[n], roll[n];

	for(int i=0; i<n; i++)
	{
		cout<<"Enter Roll NO. of Student: ";
		cin>>roll[i];
		cout<<"Enter Marks of Student " <<roll[i]<<" ";
		cin>>marks[i];

	}
	for(int i=0; i<n; i++)
	{
	
		if (marks[i]>max)
		{
			 max=marks[i];
			 no=roll[i];
		}
	}
	for(int i=1; i<n; i++)
	{
		cout<<"Roll No. "<<no <<" Marks = "<<marks;
	}

}
