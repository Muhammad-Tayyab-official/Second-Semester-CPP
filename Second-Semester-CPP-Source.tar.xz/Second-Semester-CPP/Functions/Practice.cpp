// #include <iostream>
// using namespace std;
// void print()
// {
//     cout << "Hello World" << endl;
// }
// int main()
// {
//     print();
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int print()
// {
//     cout << "Hello World" << endl;
//     return 3;
// }
// int main()
// {
//     int a;
//     a=print();
//     cout<<a<<endl;
//     cout<<print()<<endl;

//     return 0;
// }

// #include <iostream>
// using namespace std;
// int sum(int a, int b)
// {
//     return a + b;
// }
// int main()
// {
//     int result = sum(3, 4);
//     cout << "The sum is: " << result << endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int min(int a , int b)
// {
//     if (a<b)
//     {
//         return a;
//     }
//     else
//     {
//         return b;
//     }
// }
// int main()
// {
//  cout<< min(5000, 100078);
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int max(int a, int b)
// {
//     if (a > b)
//     {
//         return a;
//     }
//     else
//     {
//         return b;
//     }
// }
// int main()
// {
//     cout << max(5000, 100078);
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int sumOfseries(int n)
// {
//     int sum=0;
//     for(int i=1;i<=n;i++)
//     {
//         sum+=i;
//     }
//     return sum;
// }
// int main()
// {
//     int n;
//     cout<<"Enter the value of n: ";
//     cin>>n;
//     int result=sumOfseries(n);
//     cout<<"The sum of the series is: "<<result<<endl;
//     cout<<"The sum of the series for 5 is: "<<sumOfseries(5)<<endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int factorial(int n)
// {
//     int fact = 1;
//     if (n == 0 || n == 1)
//     {
//         return 1;
//     }
//     else
//     {
//         for (int i = 1; i <= n; i++)
//         {
//             fact *= i;
//         }
//         return fact;
//     }
// }
// int main()
// {
//     int n;
//     cout << "Enter the value of n: ";
//     cin >> n;
//     int result = factorial(n);
//     cout << "The factorial of " << n << " is: " << result << endl;
//     cout << "The factorial of 9 is: " << factorial(9) << endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int sum(int a, int b)
// {
//     a=a+10;
//     b=b+10;
//     return a + b;
// }
// int main()
// {
//     int x = 5, y = 10;
//     cout<<sum(x, y)<<endl;
//     cout << "The value of x is: " << x << endl;
//     cout << "The value of y is: " << y << endl;

//     return 0;
// }

// #include <iostream>
// using namespace std;
// // Pass by reference Function
// void sum(int &a, int &b)
// {
//     a=a+10;
//     b=b+10;
//     cout<<"The sum is: "<<a + b<<endl;
// }
// int main()
// {
//     int x = 5, y = 10;
//     sum(x, y);
//     cout << "The value of x is: " << x << endl;
//     cout << "The value of y is: " << y << endl;

//     return 0;
// }

// #include <iostream>
// using namespace std;
// int sumOfdigits(int n)
// {
//     int sum=0;
//     while(n>0)
//     {
//         int digit=n%10;
//         sum=sum+digit;
//         n=n/10;
//     }
//     return sum;
// }
// int main()
// {
//     int n;
//     cout<<"Enter the value of n: ";
//     cin>>n;
//     int result=sumOfdigits(n);
//     cout<<"The sum of the digits is: "<<result<<endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int factorial(int n)
// {
//    int fact=1;
//    for(int i=1;i<=n;i++)
//    {
//        fact=fact*i;
//    }
//     return fact;
// }
// int main()
// {
//     int n=8, r=2;
//     double result;
//     double quotient=factorial(r) * factorial(n - r);
//     result=factorial(n) / double(quotient);
//     cout<<"The value of nCr is: "<<result<<endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int factorial(int n)
// {
//     int fact=1;
//     for(int i=1;i<=n;i++)
//     {
//         fact=fact*i;
//     }
//      return fact;
// }
// int nCr(int n, int r)
// {
//     double fact_n=factorial(n);
//     double fact_r=factorial(r);
//     double fact_n_r=factorial(n-r);
//     return fact_n / (fact_r * fact_n_r);
// }
// int main()
// {
//     int n=8, r=2;
//     double result=nCr(n, r);
//     cout<<"The value of nCr is: "<<result<<endl;
//     return 0;
// }

// #include <iostream>
// using namespace std;
// int checkPrime(int n)
// {
//     if (n <= 1)
//     {
//         return 0;
//     }
//     for(int i=2; i<n; i++)
//     {
//         if(n%i==0)
//         {
//             return 0;
//         }
//     }
//     return 1;
// }
// int main()
// {
//     int n;
//     cout<<"Enter the value of n: ";
//     cin>>n;
//     int result=checkPrime(n);
//     if(result==1)
//     {
//         cout<<n<<" is a prime number."<<endl;
//     }
//     else
//     {
//         cout<<n<<" is not a prime number."<<endl;
//     }
//     return 0;
// }

// #include<iostream>
// using namespace std;
// int sumOfPrimes(int n)
// {
//    int sum=0;
//    for(int i=2; i<=n; i++)
//    {
//     int isPrime=1;
//     for(int j=2; j<i; j++)
//     {
//         if(i%j==0)
//         {
//             isPrime=0;
//             break;
//         }
//     }
//     if(isPrime==1)
//     {
//         sum=sum+i;
//     }
//     }
//     return sum;
// }
// int main()
// {
//     int n;
//     cout<<"Enter the value of n: ";
//     cin>>n;
//     int result=sumOfPrimes(n);
//     cout<<"The sum of prime numbers up to "<<n<<" is: "<<result<<endl;
//     return 0;
// }

#include <iostream>
using namespace std;
int fibonacci(int n)
{
  for(int i=0; i<n; i++)
  {
    if(i==0)
    {
        cout<<0<<" ";
    }
    else if(i==1)
    {
        cout<<1<<" ";
    }
    else
    {
        int a=0, b=1, c;
        for(int j=2; j<=i; j++)
        {
            c=a+b;
            a=b;
            b=c;
        }
        cout<<c<<" ";
    }
    }
    return 0;
}
int main()
{
    int n;
    cout<<"Enter the value of n: ";
    cin>>n;
    cout<<"The Fibonacci series up to "<<n<<" is: ";
    fibonacci(n);
    cout<<endl;
    return 0;
}