#include <iostream>
using namespace std;

int main() 
{
int price, total=0;
cout << "Enter the price of the item (enter 0 to stop): ";
    cin >> price;
    while (price != 0)
    {
        total += price;
        cout << "Enter the price of the item (enter 0 to stop): ";
        cin >> price;
    }
    cout << "Total Bill Amount:  " <<"Rs. " << total << endl;
    return 0;
}