#include<iostream>
using namespace std;
int main()
{
	
	char ch;
	cout<<"Enter Code Character: ";
	cin>>ch;
	switch(ch)
{
	case ('1'):
		{
			cout<<"Western Digital";
			break;
		}
	case ('2'):
		{
			cout<<"3M Corporation";
			break;
		}
	case ('3'):
	{
		cout<<"Maxwell Corporation";
		break;
	}
	case ('4'):
	{
		cout<<"Sony Corporation";
		break;
	}
	case('5'):
	{
		cout<<"Verbatin Corporation";
		break;
	}
}
	return 0;
	
}
