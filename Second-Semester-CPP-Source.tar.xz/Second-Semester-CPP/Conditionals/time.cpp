#include<iostream>
using namespace std;
int main()
{
	int milHour, milMin;
	char colon=':';
	cout<<"Enter Military Time (HH:MM) :";
	cin>>milHour >>colon >>milMin;
	if((milHour<0 and milHour>23) or (milMin<0 and milMin>59))
	{
		cout<<"Invalid Time!";
	}
	else
	{
		int stdHour, stdMin;
		string period;
		if (milHour==0)
		{
			stdHour=12;
			period= "AM";
		}
		else if(milHour==12)
		{
			stdHour=12;
			period="PM";
		}
		else if(milHour>12)
		{
			stdHour= milHour-12;
			period="PM";
		}
		else if(milHour<12)
		{
			stdHour = milHour;
			period= "AM";
		}
		else
		{
			cout<<"Invalid!!!";
		}
		
cout<<stdHour <<" : " <<milMin <<" " <<period;
	}
}
