#include<iostream>
using namespace std;
int main()
{
	int temp;
	cout<<"Enter Temprature: ";
	cin>>temp;
	if(temp>35)
	{
		cout<<"Hot Day!";
	}
	else if (temp>=25 and temp<35)
	{
		cout<<"Pleasent Day.";
	}
	else 
	{
		cout<<"Cold Day!";
	}
	return 0;
}
