#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"1 for Inches \n 2 for Gallons \n 3 for Miles \n 4 for Pounds" <<endl;
	cout<<"Enter Type of Conversion:";
	cin>> ch;
	switch(ch)
	{
		case('1'):
			{
				double inch,cent;
				cout<<"Enter Inches:";
				cin>>inch;
				cent= inch*2.54;
				cout<<cent;
				break;
			}
		case('2'):
			{
				double gal, lit;
				cout<<"Enter Gallons:";
				cin>>gal;
				lit=gal*3.785;
				cout<<lit;
				break;
			}
		case('3'):
			{
				double mile, km;
				cout<<"Enter Miles:";
				cin>>mile;
				km=mile*1.609;
				cout<<km;
				break;
			}
		case('4'):
			{
				double pou,kg;
				cout<<"Enter Pounds:";
				cin>>pou;
				kg=pou*0.4536;
				cout<<kg;
				break;
			}
	}
}
