#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"Enter 1st Number: ";
	cin>>a;
		cout<<"Enter 2nd Number: ";
	cin>>b;
		cout<<"Enter 3rd Number: ";
	cin>>c;
	if(a > 0)
	{
		if(b%a==0 and c%a==0)
		{
			cout<<a <<" is common devisor of " <<b <<" and " <<c ;
			
		}
		else
		cout<<a <<" is  not common devisor of " <<b <<" and " <<c ;
	}
	else
	cout<<"Enter Positive Number greater than 0.";
	return 0;
	
}
