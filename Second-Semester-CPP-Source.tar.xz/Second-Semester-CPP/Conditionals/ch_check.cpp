#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<" Enter Character : ";
	cin>> ch;
	if(ch>='a' and ch<='z')
	{
		cout<<"Its a lower case letter.";
	}
	else if(ch>='A' and ch<='Z')
	{
		cout<<"Its an upper case letter.";

	}
	else if(ch>='0' and ch<='9')
	{
		cout<<"Its a number.";
	}
	else
	{
		cout<<"Its a special character.";
	}
	return 0;
}
