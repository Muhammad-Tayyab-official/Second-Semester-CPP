#include<iostream>
using namespace std;
int main()
{
	int age;
	double month, days;
	cout<<"Enter Age in Years: ";
	cin>>age;
	month=age*12.0;
	days=age*365.0;
	cout<<"You are " <<month <<" months old." <<endl;
	cout<<"You are " <<days  <<" days old." <<endl;
return 0;
}
