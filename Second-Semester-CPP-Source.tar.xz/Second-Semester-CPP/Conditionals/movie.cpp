#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"Enter Movie Category :";
	cin>>ch;
	switch(ch)
	{
		case('A'):
			{
				cout<<"Adventure Movie";
				break;
			}
		case('C'):
			{
				cout<<"Comedy Movie";
				break;
			}
		case('F'):
			{
				cout<<"Family Movie";
				break;
			}
		case('H'):
			{
				cout<<"Horror Movie";
				break;
			}
		case('S'):
			{
				cout<<"Science Fiction Movie";
				break;
			}
		default:
			{
				cout<<"Invalid Input!!!";
			}
	}
return 0;
}
