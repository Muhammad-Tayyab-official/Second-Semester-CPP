#include<iostream>
using namespace std;
int main()
{
	int marks,per;
	cout<<"Enter Obtained Marks:";
	cin>>marks;
	per=marks/1100.0*100.0;
	if(marks>=0 and marks<=1100)
	{
		if (per>=80)
		{
			cout<<"Your grade is A+";
		}
		else if (per>=70 and per<80)
		{
			cout<<"Your grade is A";
		}
		else if (per>=60 and per<70)
		{
			cout<<"Your grade is B";
		}
		else if (per>=50 and per<60)
		{
			cout<<"Your grade is C";
		}
		else if (per>=60 and per<50)
		{
			cout<<"Your grade is D";
		}
		else
		{
			cout<<"You are Fail.";
		}
}

	return 0;
	
}
