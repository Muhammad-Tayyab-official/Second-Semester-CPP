#include<iostream>
using namespace std;
int main()
{
	int year, month , days;
	string name;
	cout<<"Enter Year: ";
	cin>>year;
	cout<<"Enter Month(1-12) :";
	cin>>month;
	switch(month)
	{
		case(1):
		{
			name="January";
			break;
		}
		case(2):
		{
			name="February";
			break;
		}
		case(3):
		{
			name="March";
			break;
		}
		case(4):
		{
			name="April";
			break;
		}
		case(5):
		{
			name="May";
			break;
		}
		case(6):
		{
			name="";
			break;
		}
		case(7):
		{
			name="";
			break;
		}
		case(8):
		{
			name="";
			break;
		}
		case(9):
		{
			name="";
			break;
		}
		case(10):
		{
			name="";
			break;
		}
		case(11):
		{
			name="";
			break;
		}
		case(12):
		{
			name="December";
			break;
		}
		default:
		{
			cout<<"Invalid Month!!!";
			break;
		}
}
	if(month==2)
	{
		if((year%4==0 and year%100 != 0) or (year%400==0))
		{
			days=29;
		}
		else
		{
			days=28;
		}
	}
	else if( month==4 or month==6 or month == 9 or month==11 )
	{
		days=30;
	}
	else
	{
		days=31;
	}

	
	
cout<<name <<" " <<year <<" has " <<days <<" days.";	
return 0;	
}
