#include<iostream>
using namespace std;
int main()
{
	int num,a,b,c;
	cout<<"Enter 3-digit Number: ";
	cin>>num;
	cout<<"You entered " <<num <<endl;
	a=num/100;
	num=num%100;
	b=num/10;
	c=num%10;
	cout<<a <<endl <<b <<endl <<c <<endl;
	return 0;
	
}
