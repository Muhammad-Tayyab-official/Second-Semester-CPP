#include<iostream>
using namespace std;
int main()
// {
// 	int temp;
// 	char ch;
// 	cout<<"Enter Temprature: ";
// 	cin>>temp;
// 	cout<<"Enter Unit (f for Farenhite and c for Celsius) : ";
// 	cin>>ch;
// 	if(ch=='f' or ch=='F')
// 	{
// 		double cel;
// 		cel= (temp-32)* 5/9.0;
// 		cout<<"Temprature in Celsius : "<<cel;
// 	}
// 	else if(ch=='c'|| ch=='C')
// 	{
// 		double far;
// 		far= (temp*9/5.0)+32;
// 	}
// 	else
// 	{
// 		cout<<"Invalid Input!!!";
// 	}
// 	return 0;
	
// }
// {
// 	double x, num, square, total=0;

// 	for (int i=0; i<7; i++)
// 	{
// 		cout<<"Enter a number: ";47

// 		cin>>x;
// 		num=x-69.6;
// 		square=num*num;
// 		cout<<"Square of "<<num<<" is "<<square<<endl;
// 		total=total+square;
// 	}
	
// 	cout<<"Total of squares is: "<<total;
	
// }