#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"Enter 's' or 'S' for Senior :" <<endl;
		cout<<"Enter 'j' or 'J' for Junior :" <<endl;
	cout<<"Enter Your Choice: ";
	cin>>ch;
	if (ch=='s' or ch=='S')
	{
		cout<<"Salary for Senior Person is " <<4*400;
	}
	else if(ch=='j' or ch=='J')
	{
		cout<<"Salary for Junior Person is " <<4*275;
	}
	else
	cout<<"Wrong Input!!!";
	return 0;
}
