#include<iostream>
using namespace std;
int main()
{
	int salary,tax;
	cout<<"Enter Salary :";
	cin>>salary;
	if (salary>30000)
	{
		tax=(15/100.0)*salary;
		cout<<"Salary : " <<salary <<endl;
		cout<<"Income Tax : " <<tax <<endl;
		cout<<"Net Salary : " <<salary-tax <<endl;
	}
	else if(salary>20000 and salary<=30000)
	{
		tax=(15/100.0)*salary;
		cout<<"Salary : " <<salary <<endl;
		cout<<"Income Tax : " <<tax <<endl;
		cout<<"Net Salary : " <<salary-tax <<endl;
	}
	else
	{
		tax=(15/100.0)*salary;
		cout<<"Salary : " <<salary <<endl;
		cout<<"Income Tax : " <<tax <<endl;
		cout<<"Net Salary : " <<salary-tax <<endl;
	}
	return 0;
}
