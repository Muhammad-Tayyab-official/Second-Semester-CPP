#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"Press S for Area of Square and T for Area of Triangle."<<endl;
	cout<<"Enter Choice : ";
	cin>>ch;
	switch(ch)
	{
	case 'S':
	case 's':
	{
		int side;
		cout<<"Enter Side of Square : ";
		cin>>side;
		cout<<"Area of Square is " <<side*side;
		break;
	}
	case 'T':
	case 't':
	{
		int base, h;
		cout<<"Enter Base : ";
		cin>>base;
		cout<<"Enter Height  : ";
		cin>>h;
		cout<<"Area of Triangle is "<< 0.5*base*h;
		break;
	}
		default:
		{
			cout<<"Invalid Input!!!";
		}
}
return 0;
}
