#include<iostream>
using namespace std;
 
struct Shipment {
    int id;
    float weight;
    float distance;
    char type;  // E = Express, N = Normal
};
 
void inputShipmentData(Shipment s[], int n) {
    for(int i=0; i<n; i++) {
        cout << "\nShipment " << i+1 << ":" << endl;
        cout << "ID: ";       cin >> s[i].id;
        cout << "Weight: ";   cin >> s[i].weight;
        cout << "Distance: "; cin >> s[i].distance;
        cout << "Type (E/N): "; cin >> s[i].type;
    }
}
 
float calculateBaseCost(float weight, float distance) {
    return (weight * 50) + (distance * 10);
}
 
float applyDeliveryTypeCharge(float cost, char type) {
    if(type == 'E' || type == 'e')
        return cost * 1.30;
    return cost;
}
 
void determineDeliveryStatus(float distance) {
    if(distance <= 50)
        cout << "Local Delivery" << endl;
    else if(distance <= 200)
        cout << "Regional Delivery" << endl;
    else
        cout << "Long Distance Delivery" << endl;
}
 
void generateInvoice(Shipment s) {
    float base  = calculateBaseCost(s.weight, s.distance);
    float total = applyDeliveryTypeCharge(base, s.type);
 
    cout << "\n--- Invoice ---" << endl;
    cout << "Tracking ID : " << s.id << endl;
    cout << "Type        : " << (s.type=='E'?"Express":"Normal") << endl;
    cout << "Final Cost  : " << total << endl;
    cout << "Category    : "; determineDeliveryStatus(s.distance);
}
 
int main() {
    Shipment s[5];
    inputShipmentData(s, 5);
    for(int i=0; i<5; i++)
        generateInvoice(s[i]);
    return 0;
}
