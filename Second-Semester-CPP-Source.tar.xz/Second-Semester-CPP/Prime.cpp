#include<iostream>
using namespace std;

int main() {
    int n = 3;
    int input;
    int array[n]; // Stores the numbers entered
    int primeCount = 0;

    for(int r = 0; r < n; r++) { 
        cout << "Enter Number " << r + 1 << ": ";
        cin >> input;

        int divisors = 0;
        // Check for divisors from 1 to input
        for(int i = 1; i <= input; i++) {
            if(input % i == 0) {
                divisors++;
            }
			else
			{
			 array[r] = 0; // Not a prime number, store 0 or any indicator
			}
        }

        // A prime number has exactly 2 divisors: 1 and itself
        if(divisors == 2) {
            array[r] = input;
        } 
    }
	for(int r=0; r<n; r++)
	{
		cout<<array[r]<<" ";
	}

    return 0;
}