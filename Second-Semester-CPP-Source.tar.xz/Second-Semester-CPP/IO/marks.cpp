#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d,e,total, per;
	cout<<"Enter Marks in 1st Subject :" ;
	cin>>a;
	cout<<"Enter Marks in 2nd Subject :" ;
	cin>>b;
	cout<<"Enter Marks in 3rd Subject :" ;
	cin>>c;
	cout<<"Enter Marks in 4th Subject :" ;
	cin>>d;
	cout<<"Enter Marks in 5th Subject :" ;
	cin>>e;
	total=a+b+c+d+e;
	per=total/5.0;
	cout<<"Total Marks = " <<total <<endl ;
	cout<<"Percentage = " <<per <<"%"<<endl ;
	return 0;
	
}
