#include<iostream>
using namespace std;
int main()
{
	int tp,rpd,dp;
	int rp, rep;
	cout<<"Enter Total Number of Pages in the Book: ";
	cin>>tp;
	cout<<"Enter Number of pages a person read in one day: ";
	cin>>rpd;
	cout<<"Enter Number of days a Person Read the Book: ";
	cin>>dp;
	rp=rpd*dp;
	rep= tp-rp;
	cout<<"Number of Pages Read by a Person is " <<rp <<endl;
	cout<<"Number of Pages Remaining in the Book are "<<rep <<endl;
	return 0;
	
}
