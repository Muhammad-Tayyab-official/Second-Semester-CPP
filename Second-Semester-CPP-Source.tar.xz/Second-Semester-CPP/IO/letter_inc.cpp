#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"Enter a Letter : ";
	cin>>ch;
	cout<<"Next two letters are " <<++ch <<"\t" <<++ch;
	
}
