#include<iostream>
using namespace std;
int main()
{
	int pet;
	double dist;
	cout<<"Enter Petrol in Liters: ";
	cin>>pet;
	dist= pet*5.3;
	cout<<"Your car can travel " <<dist <<" miles in " <<pet <<" Liters petrol.";
	return 0; 
}
