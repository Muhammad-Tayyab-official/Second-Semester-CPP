#include<iostream>
using namespace std;
int main()
{
	double far, cel;
	cout<<"Enter Temprature in Farenhite: ";
	cin>>far;
	cel= 5/9.0*(far-32);
	cout<<"Temprature in Celcius is "<<cel <<endl;
	return 0;
	
}
