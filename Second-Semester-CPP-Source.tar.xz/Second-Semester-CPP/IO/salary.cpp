#include<iostream>
using namespace std;
int main()
{
	int bs;
	double dear, rent, gross;
	cout<<"Enter Basic Salary: ";
	cin>>bs;
	dear= bs*(35/100.0);
	rent= bs*(25/100.0);
	gross= bs+dear+rent;
	cout<<"Gross Salary is "<<gross;
	return 0;
	
}
