#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a,b,c;
	double s, area;
	cout<<"For a Triangle Sum of two sides should must be greater than third side."<<endl;
		cout<<"Enter 1st Side of Triangle: ";
	cin>>a;
		cout<<"Enter 2nd Side of Triangle: ";
	cin>>b;
		cout<<"Enter 3rd Side of Triangle: ";
	cin>>c;
	s=(a+b+c)/2.0;
	area=sqrt(s*(s-a)*(s-b)*(s-c));
	cout<<"Area of Triangle: "<<area;
return 0;
}
