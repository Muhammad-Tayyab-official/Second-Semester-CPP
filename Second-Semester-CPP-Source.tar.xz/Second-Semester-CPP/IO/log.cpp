#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int num;
	cout<<"Enter a Positive number: ";
	cin>>num;
	cout<<"Logarithm of the number with the base 2 is "<<log2(num);
}
