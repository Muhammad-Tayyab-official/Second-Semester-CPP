#include <iostream>
using namespace std;  
int main()
{
    int a,b;
    float marks;
    a=10;
    b=5;
    cout<<"Enter Marks:";
    cin>>marks;
    cout<<"Sum:" <<a+b;
    cout<<"\nMarks:"<<marks;
    return 0;
}