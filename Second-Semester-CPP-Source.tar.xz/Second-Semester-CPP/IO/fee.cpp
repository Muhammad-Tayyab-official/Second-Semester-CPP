#include<iostream>
using namespace std;
int main()
{
	int st, fee;
	double total;
	cout<<"Enter Number of Students in Class: ";
	cin>>st;
	cout<<"Enter Amount of Fee Per Student: ";
	cin>>fee;
	total= st*fee;
	cout<<"Total fee collected from whole class: " <<total;
	return 0;
}
