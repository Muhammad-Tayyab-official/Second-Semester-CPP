#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int r;
	double area, cir;
	cout<<"Enter Radius: ";
	cin>>r;
	area= 4*(3.14)*r*r;
	cir= 4/3.0*3.14*r*r*r;
	cout<<"Surface Area= "<<area<<endl;
	cout<<"Circumference= "<<cir<<endl;
}
