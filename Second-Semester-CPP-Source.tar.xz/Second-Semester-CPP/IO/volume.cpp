#include<iostream>
using namespace std;
int main()
{
	int len, wid, h;
	double vol;
	cout<<"Enter Length of Cube: ";
	cin>>len;
	cout<<"Enter Width of Cube: ";
	cin>>wid;
	cout<<"Enter Height of Cube: ";
	cin>>h;
	vol=len*wid*h;
	cout<<"Volume of Cube is "<<vol;
}
