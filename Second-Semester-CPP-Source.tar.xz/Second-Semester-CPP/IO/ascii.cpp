#include<iostream>
using namespace std;
int main()
{
	char num;
	cout<<"Enter Any Character: ";
	cin>>num;
	cout<<"ASCII code for your number is  "<<int(num);
	return 0;
}
