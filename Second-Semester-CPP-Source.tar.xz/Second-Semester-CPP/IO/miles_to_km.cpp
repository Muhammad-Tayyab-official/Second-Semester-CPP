#include<iostream>
using namespace std;
int main()
{
	double miles, km;
	cout<<"Enter Distance in Miles:";
	cin>>miles;
	km=1.609*miles;
	cout<<"Distance in Kilometers is "<<km <<"km." <<endl;
	return 0;
}
