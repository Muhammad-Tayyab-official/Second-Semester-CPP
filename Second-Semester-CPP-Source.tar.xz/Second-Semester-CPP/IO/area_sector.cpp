#include<iostream>
using namespace std;
int main()
{
	float angle, r;
	double area;
	cout <<"Enter Angle in Radians: ";
	cin>>angle;
	cout<<"Enter Radius of Circle: ";
	cin>>r;
	area=(1/2.0)*angle*r*r;
	cout <<"Area of sector is " <<area;
	return 0;
	
}
