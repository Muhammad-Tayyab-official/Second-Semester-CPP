#include<iostream>
using namespace std;
int main()
{
	double a,b,c,d,sum,avg,pro;
	cout<<"Enter 1st Number: ";
	cin>>a;
	cout<<"Enter 2nd Number: ";
	cin>>b;
	cout<<"Enter 3rd Number: ";
	cin>>c;
	cout<<"Enter 4th Number: ";
	cin>>d;
	
sum= a+b+c+d;
avg=(sum)/4.0;
pro=a*b*c*d;
cout<<"Sum of 4 Numbers is: "<< sum<<endl;
cout<<"Average of 4 Numbers is: "<< avg<<endl;
cout<<"Product of 4 Numbers is: "<< pro<<endl;
return 0;
	
}
