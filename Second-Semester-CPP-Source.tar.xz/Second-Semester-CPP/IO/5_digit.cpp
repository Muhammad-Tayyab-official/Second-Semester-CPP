#include<iostream>
using namespace std;
int main()
{
  int num,a,b,c,d,e,sum;
  cout<<"Enter a 5-digit Number: ";
  cin>>num;
  a=num/10000;
  num=num%10000;
  b=num/1000;
  num=num%1000;
  c=num/100;
  num=num%100;
  d=num/10;
  e=num%10;
   sum=a+b+c+d+e;
   cout<<"Sum of 5-digits of a number is "<<sum;
   return 0;
   
  
}
