#include<iostream>
using namespace std;
int main()
{
	float r, angle;
	double len;
	cout<<"Enter Radius of Convex Lens:";
	cin>>r;
	cout<"Enter Angle Made by Arc: ";
	cin>>angle;
	len= r*angle;
	cout<<"Length of Arc is:" <<len;
	
}
