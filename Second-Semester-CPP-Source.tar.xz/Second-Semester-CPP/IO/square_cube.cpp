#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int n;
	double sq, cu;
	cout<<"Enter a Number: ";
	cin>>n;
	sq= pow(n,2);
	cu= pow(n,3);
	cout<<"Square of the Number is "<< sq <<endl;
	cout<<"Cube of the Number is "<<cu <<endl;
	return 0;
	
	
}
