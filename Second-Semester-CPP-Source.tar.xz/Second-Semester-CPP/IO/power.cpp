#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n=1;
	cout<<"Number\t" <<"Square\t" <<"Cube" <<endl;
		cout<<n <<"\t" <<pow(n,2) <<"\t" <<pow(n,3) <<endl;
	n++;
		cout<<n <<"\t" <<pow(n,2) <<"\t" <<pow(n,3) <<endl;
	n++;
		cout<<n <<"\t" <<pow(n,2) <<"\t" <<pow(n,3) <<endl;
	n++;
		cout<<n <<"\t" <<pow(n,2) <<"\t" <<pow(n,3) <<endl;
	n++;
		cout<<n <<"\t" <<pow(n,2) <<"\t" <<pow(n,3) <<endl;
	n++;
return 0;	
}
