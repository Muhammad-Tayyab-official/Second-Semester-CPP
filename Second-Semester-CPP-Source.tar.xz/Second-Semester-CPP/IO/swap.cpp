#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	cout<<"Enter 1st Value: ";
	cin>>a;
	cout<<"Enter 2nd  Value: ";
	cin>>b;
	cout<<"Enter 3rd Value: ";
	cin>>c;
	cout<<" a= "<<a <<"\t b= " <<b <<"\t c= " <<c <<endl;
	d=a;
	a=b;
	b=c;
	c=d;
	cout<<"Swapped Values are:";
	cout<<" a= "<<a <<"\t b= " <<b <<"\t c= " <<c<< endl;
	
}

