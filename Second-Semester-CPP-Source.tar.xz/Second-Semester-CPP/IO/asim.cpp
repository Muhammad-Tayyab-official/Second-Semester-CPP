#include<iostream>
using namespace std;
int main()
{int a,n,mar;
cout<<"enter a num";
cin>>a;
cout<<"enter other num";
cin>>n;
cout<<a<<n;
return 0;

}
