#include<iostream>
using namespace std;
int main()
{
// Hospital Management System
int age, income;
cout<<" Enter Age: ";
cin>>age;
cout<<"Enter Income: ";
cin>>income;
if(age<16 or income<35000)
{
    cout<<" Not Eligible!!!"<<endl;
}
else
{
    if((age>30 and age<50) and income>=65000)
    {
        cout<<" Critical Care Priority Patient"<<endl;
    }
    else
    {
        if(income>=55000)
        {
            cout<<"Eligible for Full Assistance"<<endl;
        }
        else if(income>=35000 and income<55000)
        {
            cout<<"Eligible for Partial Assistance"<<endl;
        }
        else
        {
            cout<<"Not Eligible!!!"<<endl;
        }
    }
}
int n, count=0;
cout<<"Number of Daily Checkups: ";
cin>>n;
for(int i=1; i<=n; i++)
{
    if(i%4==0)
    {
        continue;
    }
    if(i%10==0)
    {
        break;
    }
    cout<<"checkup number "<<i<<endl;
    count++;

}
cout<<"\nTotal Count of Checkups: "<<count<< endl; 
// Performance of Different Wards Based pn Recovery Score(Using 2D array)
 const int ward = 4;
    const int Patient = 4;
    int recoveryScore[ward][Patient];
    int input;
    int t[ward] = {0};  // Initialize all elements to 0
    
    for(int row = 0; row < ward; row++) {
        t[row] = 0;  // Initialize sum for this ward
        
        for(int col = 0; col < Patient; col++) {
            cout << "Enter Recovery Score for Ward " << row + 1 
                 << " Patient " << col + 1 << ": ";
            cin >> input;
            
            if(input < 0 or input > 100) {
                cout << "Invalid Recovery Score. Please enter a value between 0 and 100." << endl;
                col--;  // Decrement col to re-enter this patient's score
                continue;
            }
            else {
                recoveryScore[row][col] = input;
            }
            
            if(input < 25) {
                cout << "Alert: Patient in Ward " << row + 1 
                     << " Patient " << col + 1 
                     << " has a critical recovery score of " << input << "." << endl;
            }
            
            t[row] += input;
        }
        
        cout << "Total Recovery Score for Ward " << row + 1 << ": " << t[row] << endl;
        cout << "Average Recovery Score for Ward " << row + 1 << ": " 
             << t[row] / Patient << endl;
        
        if(t[row] / Patient >= 80) {
            cout << " Excellent Ward!!!" << endl;
            cout << "Excellent Performance: Ward " << row + 1 
                 << " has an average recovery score of " << t[row] / Patient << "." << endl;
        }
        else if(t[row] / Patient >= 65) {
            cout << " Stable Ward!!!" << endl;
            cout << "Satisfactory Performance: Ward " << row + 1 
                 << " has an average recovery score of " << t[row] / Patient << "." << endl;
        }
        else {
            cout << "Critical Ward!!" << endl;
            cout << "Warning: Ward " << row + 1 
                 << " has an average recovery score of " << t[row] / Patient 
                 << ", which is below the acceptable threshold." << endl;
        }
    }
    
    return 0;
}  